package com.example.recyclerview;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.LinkedList;

public class RvAdapter extends RecyclerView.Adapter<RvAdapter.IniViewHolder> {
    private LayoutInflater inflater;
    private LinkedList<String> daftarNama;

    RvAdapter(Context context, LinkedList<String> list){
        inflater = LayoutInflater.from(context);
        daftarNama = list;
    }

    @NonNull
    @Override
    public IniViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = inflater.inflate(R.layout.item_list, parent, false);
        return new IniViewHolder(view, this);
    }

    @Override
    public void onBindViewHolder(@NonNull IniViewHolder holder, int position) {
        holder.tvRv.setText(daftarNama.get(position));
    }

    @Override
    public int getItemCount() {
        return daftarNama.size();
    }

    public class IniViewHolder extends RecyclerView.ViewHolder {
        TextView tvRv;
        RvAdapter iniAdapter;
        public IniViewHolder(@NonNull View itemView, RvAdapter adapter) {
            super(itemView);
            tvRv = itemView.findViewById(R.id.tvRv);
            iniAdapter = adapter;
        }
    }
}
