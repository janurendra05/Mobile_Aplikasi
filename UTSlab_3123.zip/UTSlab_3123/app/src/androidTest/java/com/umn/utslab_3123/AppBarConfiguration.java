package com.umn.utslab_3123;

public enum AppBarConfiguration {
}
