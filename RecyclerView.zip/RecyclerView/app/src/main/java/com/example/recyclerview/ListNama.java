package com.example.recyclerview;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Toast;

import java.util.LinkedList;

public class ListNama extends AppCompatActivity {
    RecyclerView iniRv;
    RvAdapter rvAdapter;
    LinkedList<String> daftarNama = new LinkedList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list_nama);
        Intent intent = getIntent();
        Toast.makeText(this, intent.getStringExtra("extras"), Toast.LENGTH_LONG).show();

        for(int i = 0 ; i < 10 ; i++){
            daftarNama.add("Ini orang ke "+ (i+1));
        }

        iniRv = findViewById(R.id.iniRv);
        rvAdapter = new RvAdapter(this, daftarNama);
        iniRv.setAdapter(rvAdapter);
        iniRv.setLayoutManager(new LinearLayoutManager(this));
    }
}